<?php 
    ob_start();
    session_start();
    mysql_connect("localhost","juitieee_root","password");
    mysql_select_db("juitieee_hostel");
 ?>