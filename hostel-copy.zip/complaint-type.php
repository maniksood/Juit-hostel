<?php include 'config.php'; ?>

<!doctype html>
    <html lang="en">
        <head>
            <title>
                Hostel Complaints - JUIT
            </title>
            <link type="text/css" href="css/bootstrap.css" rel="stylesheet">
            <link href='http://fonts.googleapis.com/css?family=Alegreya+Sans+SC:400,500italic' rel='stylesheet' type='text/css'>
            </head>
            <body>
             <div class="container-fluid" >
                 <div class="row">
                 <div class="col-md-12">
                     
                     <div style="background-color:#4F827C;padding:10px 10px 10px 10px;margin-left:-20px;margin-right:-20px;">
                 <center><h2 style="font-family: 'Alegreya Sans SC', sans-serif;color:white"><b>Hostel Complaint Registration Portal</b></h2></center> 
                     </div>
                         <br><br> <br><br><br><br>
                 </div>
                 </div>
                 <div class="row">
                     <center>
                         <h1>Select Type Of Complaint</h1>
                         <br>
                     </center>
                 </div>
                 
                 <div class="row">
                     <div class="col-md-4"></div>
                     <div class="col-md-4">
                     
 <table class="table table-bordered table-hover">
 <form action="" method="post">
        <tr>
            <th>General Hostel Complaint</th>
            <td>
                <div class="col-md-4">
                    <a href="complaint.php" name="update-as-completed" class="btn btn-large btn-success">Log Complaint</a>
                </div>
            </td>
        </tr>
        <tr>
            <th>Hostel Warden Complaint</th>
            <td>
                <div class="col-md-4">
                    <a href="warden-complaint.php" name="update-as-subadmin" class="btn btn-large btn-success">Log Complaint</a>
                </div>
            </td>
        </tr>
        <tr>
            <th>Server Room Complaints</th>
            <td>
                <div class="col-md-4">
                    <a href="server-complaint.php" name="update-as-admin" class="btn btn-large btn-success">Log Complaint</a>
                </div>
            </td>
        </tr>
    </form>
</table>
                         
                     </div>
                     <div class="col-md-4"></div>
                     
                     
                </div>
                 
                 
                    
            </div>
            </body>
        </head>
    </html>

    <?php 
    if (isset($_POST['login'])) {
        $id = $_POST['id'];
        $password = $_POST['password'];
        $password = md5($password);

        $select_login = "select * from users where id = '$id' and password = '$password'";
        $result_login = mysql_query($select_login) or die(mysql_error());
        $res_login = mysql_fetch_assoc($result_login);

        if ($res_login) { 
            echo "Login Successful";
            $_SESSION['user-login-id'] = $res_login['id'];
            $_SESSION['user-login-name'] = $res_login['name'];
            header('location:complaint.php');
         }
        else{
            echo "<script>alert('Incorrect email or password');</script>";
        }
    }
 ?>